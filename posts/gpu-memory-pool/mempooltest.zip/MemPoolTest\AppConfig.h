//=================================================================================================
//
//  D3D12 Memory Pool Performance Test
//  by MJP
//  https://therealmjp.github.io/
//
//  All code and content licensed under the MIT license
//
//=================================================================================================

#define EnableSkyModel_ (0)
#define EnableEmbree_ (0)
#define EnableDXR_ (0)
#define EnableSM66_ (0)