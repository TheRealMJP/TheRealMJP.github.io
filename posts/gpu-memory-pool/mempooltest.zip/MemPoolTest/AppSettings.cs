enum HeapTypes
{
    Upload,
    Default,
    Custom,

    [EnumLabel("NVAPI CPU-Writable VRAM")]
    NvVRAM,
}

enum CPUPageProperties
{
    [EnumLabel("Not Available (No CPU Access)")]
    NotAvailable,

    [EnumLabel("Write-Combined (Uncached)")]
    WriteCombine,

    [EnumLabel("Write-Back (Cached)")]
    WriteBack
}

enum MemoryPools
{
    [EnumLabel("L0 (CPU RAM)")]
    L0,

    [EnumLabel("L1 (VRAM)")]
    L1
}

enum BufferTypes
{
    Raw,
    Formatted,
    Structured,
    Constant,
}

public class Settings
{
    const uint ThreadGroupSize = 256;

    public class TestConfig
    {
        HeapTypes HeapType = HeapTypes.Default;

        [DisplayName("Heap CPUPageProperty")]
        [Visible(false)]
        [UseAsShaderConstant(false)]
        CPUPageProperties CPUPageProperty = CPUPageProperties.NotAvailable;

        [DisplayName("Heap MemoryPool")]
        [Visible(false)]
        [UseAsShaderConstant(false)]
        MemoryPools MemoryPool = MemoryPools.L0;

        [UseAsShaderConstant(false)]
        BufferTypes InputBufferType = BufferTypes.Raw;

        [MinValue(0)]
        [MaxValue(256)]
        [UseAsShaderConstant(false)]
        int InputBufferSizeMB = 64;

        [MinValue(0)]
        [MaxValue(1024)]
        [UseAsShaderConstant(false)]
        int InputBufferSizeKB = 0;

        [MinValue(0)]
        [MaxValue(1024)]
        [UseAsShaderConstant(false)]
        int InputBufferSizeBytes = 0;

        [MinValue(1)]
        [MaxValue(64)]
        [UseAsShaderConstant(false)]
        int ElemsPerThread = 16;

        [MinValue(1)]
        [MaxValue(64)]
        [UseAsShaderConstant(false)]
        int ThreadElemStride = 1;

        [MinValue(0)]
        [MaxValue(16)]
        [UseAsShaderConstant(false)]
        int GroupElemOffset = 1;

        [MinValue(0)]
        [MaxValue(16)]
        [UseAsShaderConstant(false)]
        int ThreadElemOffset = 1;

        [MinValue(1)]
        [MaxValue(65535)]
        [UseAsShaderConstant(false)]
        int NumThreadGroups = 16384;

        [DisplayName("Read From GPU Memory")]
        [UseAsShaderConstant(false)]
        bool ReadFromGPUMem = false;

        [DisplayName("Upload With COPY Queue")]
        [UseAsShaderConstant(false)]
        bool UploadWithCopyQueue = true;

        [Visible(false)]
        [UseAsShaderConstant(false)]
        int NumInputBufferElems = 0;

        [Visible(false)]
        int InputBufferIdx = -1;
    }

    [ExpandGroup(true)]
    public class Debug
    {
        [UseAsShaderConstant(false)]
        [DisplayName("Enable VSync")]
        [HelpText("Enables or disables vertical sync during Present")]
        bool EnableVSync = true;

        [UseAsShaderConstant(false)]
        [HelpText("Enables the stable power state, which stabilizes GPU clocks for more consistent performance")]
        bool StablePowerState = true;

        [UseAsShaderConstant(false)]
        bool EnableDriverBackgroundThreads = false;
    }
}